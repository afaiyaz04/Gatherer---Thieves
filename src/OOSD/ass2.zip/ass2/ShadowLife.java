package OOSD.ass2;
import bagel.*;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;


public class ShadowLife extends AbstractGame {
    public World world;

    /** To create the game, a file is read
     * individiual arrays for diff types of objects are created
     */
    public ShadowLife(String[] args) {
        this.world = new World(Integer.parseInt(args[0]),Integer.parseInt(args[1]), args[2],
                "res/images/background.png");
    }
    /*
     * The entry point for the Game, ShadowLife
     */
    public static void main(String[] args) {
        String[] arguments = argsFromFile();
        if (arguments.length != 3 || Integer.parseInt(arguments[0])<0 || Integer.parseInt(arguments[1])<0) {
            System.out.printf("usage: ShadowLife %s %s %s\n",arguments[0],arguments[1],arguments[2]);
            System.exit(-1);
        }
        ShadowLife game = new ShadowLife(arguments);
        game.run();
    }


    /*
     * Performs a state update every tick(500ms)
     * The movement of the objects are added here
     */
    @Override
    public void update(Input input) {
        world.update();

    }

    private static String[] argsFromFile() {
        try {
            return Files.readString(Path.of("args.txt"), Charset.defaultCharset())
                    .split(" ");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}


