package OOSD.ass2;

import bagel.*;
import bagel.Font;

public class FruitPile extends Actor {
    public int fruitCount;
    public Font font;
    public static final String TREE = "Tree";
    public static final String GOLDTREE = "GoldenTree";
    public static final String STOCKPILE = "Stockpile";
    public static final String HOARDS = "Hoard";

    public FruitPile(String type, Point position){
        this.font = new Font("res/VeraMono.ttf",24);
        switch (type) {
            case TREE:
                this.fruitCount = 3;
                this.type = TREE;
                this.position = new Point(position);
                this.image =  new Image("res/images/tree.png");
                break;
            case GOLDTREE:
                this.fruitCount = Integer.MAX_VALUE;
                this.type = GOLDTREE;
                this.position = new Point(position);
                this.image =  new Image("res/images/gold-tree.png");
                break;
            case STOCKPILE:
                this.fruitCount = 0;
                this.type = STOCKPILE;
                this.position = new Point(position);
                this.image =  new Image("res/images/cherries.png");
                break;
            case HOARDS:
                this.fruitCount = 0;
                this.type = HOARDS;
                this.position = new Point(position);
                this.image =  new Image("res/images/hoard.png");
                break;
        }
    }

    @Override
    public void update(Tick tick) {
        render();
        if(!this.type.equals(FruitPile.GOLDTREE)){
            font.drawString(Integer.toString(this.fruitCount),position.getX(),position.getY());
        }

    }
}
