package OOSD.ass2;

import bagel.Image;
import bagel.Window;
import java.util.ArrayList;
import java.util.HashMap;

public class World {
    private final Image background;
    public static ArrayList<Actor> characters;
    public static HashMap<Integer,ArrayList<Actor>> charMap;
    private final Tick tick;
    public static final int TILE_SIZE = 64;
    public final int tickValue;
    public final int maxTick;
    public final Reader inputFile;

    public World( int tickValue, int maxTick, String worldFile, String backgroundFile){
        this.background = new Image(backgroundFile);
        inputFile= new Reader(worldFile);
        this.tickValue = tickValue;
        this.maxTick = maxTick;
        tick = new Tick(this.tickValue);
        characters = new ArrayList<>();
        charMap = new HashMap<>();
        inputFile.worldReader(characters);
    }

    public static void addToMap(Point point, Actor character) {
        Integer tileNum = World.tileNumCalculator(point);
        ArrayList<Actor> charList = charMap.get(tileNum);

        // if list does not exist create it
        if(charList == null) {
            charList = new ArrayList<>();
            charList.add(character);
            charMap.put(tileNum, charList);
        } else {
            // add if Car is not already in list
            if(!charList.contains(character)) {
                charList.add(character);
            }
        }
        System.out.println("total actors- "+World.charMap.size() );
    }

    public void update(){
        background.draw(Window.getWidth() / 2.0, Window.getHeight() / 2.0);
        tick.run();
        for(int i=0;i<World.characters.size();i++){
            World.characters.get(i).update(this.tick);
        }
    }

    public static Integer tileNumCalculator(Point point){
        int x = point.getX()/64;
        int y = point.getY()/64;
        return x+(16*y);
    }
}

