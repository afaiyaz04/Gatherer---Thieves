package OOSD.ass2;
import java.util.Random;

/** Used from the assignment 1 solution
 * code of Rohyl
 */
public class Direction {
    public static final int UP = 0;
    public static final int RIGHT = 1;
    public static final int DOWN = 2;
    public static final int LEFT = 3;
    public static final int CLOCKWISE = 1;
    public static final int ANTICLOCKWISE = -1;

    public static int getRandom() {
        // Directions are random between 0 and 3.
        Random rand = new Random();
        return rand.nextInt(RIGHT + 1);
    }
    public static int rotation180(int direction){
        int newDir = direction-2;
        if(newDir == -1){
            return Direction.LEFT;
        }
        else if(newDir==-2){
            return Direction.DOWN;
        }
        else {
            return newDir;
        }
    }

    public static int rotation90(int direction,int rotation){
        System.out.println(direction);
        int newDir = direction + rotation;
        if(newDir==-1){
            System.out.println(newDir);
            return Direction.LEFT;
        }
        else if(newDir==4){
            System.out.println(newDir);
            return Direction.UP;
        }
        else{
            System.out.println(newDir);
            return newDir;
        }
    }
}

