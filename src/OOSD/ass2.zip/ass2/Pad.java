package OOSD.ass2;

import bagel.Image;

public class Pad extends Actor {
    public static final String IDENTIFIER= "Pad";

    public Pad(Point position){
        this.type = "Pad";
        this.position = new Point(position);
        this.image = new Image("res/images/pad.png");
    }

    @Override
    public void update(Tick tick) {
        render();
    }
}
