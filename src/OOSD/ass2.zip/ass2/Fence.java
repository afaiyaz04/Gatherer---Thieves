package OOSD.ass2;

import bagel.Image;

public class Fence extends Actor {
    public static final String IDENTIFIER= "Fence";

    public Fence(Point position){
        this.type = "Fence";
        this.position = new Point(position);
        this.image = new Image("res/images/fence.png");
    }

    @Override
    public void update(Tick tick) {
        render();
    }
}