package OOSD.ass2;
import bagel.Image;


/** One of the objects in the game
 *  it has a position and the direction if its moving
 *  it also contains an image
 */
public class Gatherer extends Player {
    public static final String IDENTIFIER = "Gatherer";

    public Gatherer(Point position) {
        this.type = "Gatherer";
        this.position = new Point(position);
        this.direction = Direction.LEFT;
        this.carrying = false;
        this.active = true;
        this.standingOn = World.charMap.get(World.tileNumCalculator(this.position));
        this.image = new Image("res/images/Gatherer.png");

    }
    public Gatherer(Point position,int direction) {
        this.type = "Gatherer";
        this.position = new Point(position);
        this.direction = direction;
        this.carrying = false;
        this.active = true;
        this.standingOn = World.charMap.get(World.tileNumCalculator(this.position));
        this.image = new Image("res/images/Gatherer.png");

    }

    @Override
    public void update(Tick tick) {
        if (tick.tickComplete) {
            if(active){
                System.out.println("HAPPEDNED HEERE 1");
                move(this.direction, World.TILE_SIZE);
                standingOn =World.charMap.get(World.tileNumCalculator(this.position));
            }
            if(standingOn!=null){
                System.out.println("FOUND");
                for(Actor things:standingOn){
                    interact(things);
                    System.out.println(this.position.toString());
                    System.out.println(things.type);
                }
            }
        }
        render();
    }

    @Override
    public void interact(Actor object) {
        if(object.type.equals(Fence.IDENTIFIER)) {
            this.direction= Direction.rotation180(this.direction);
            System.out.println("HAPPEDED HEREE 2");
            move(this.direction,World.TILE_SIZE);
            standingOn=World.charMap.get(World.tileNumCalculator(this.position));
            this.active = false;
        }

        if((object.type.equals(FruitPile.TREE) || object.type.equals(FruitPile.GOLDTREE)) && carrying==false){
            FruitPile tree =(FruitPile) object;
            if(tree.fruitCount!=0){
                tree.fruitCount--;
                carrying = true;
                direction = Direction.rotation180(this.direction);
            }
        }

        if((object.type.equals(FruitPile.STOCKPILE) || object.type.equals(FruitPile.HOARDS))){
            FruitPile pile =(FruitPile) object;
            if(carrying){
                carrying = false;
                pile.fruitCount++;
            }
            direction = Direction.rotation180(this.direction);
        }

        if(object.type.equals(Sign.UP)){
            Sign sign =(Sign) object;
            this.direction = sign.direction;
        }
        else if(object.type.equals(Sign.DOWN)){
            Sign sign =(Sign) object;
            this.direction = sign.direction;
        }
        else if(object.type.equals(Sign.RIGHT)){
            Sign sign =(Sign) object;
            this.direction = sign.direction;
        }
        else if(object.type.equals(Sign.LEFT)){
            Sign sign =(Sign) object;
            this.direction = sign.direction;
        }
        if(object.type.equals(MitosisPool.IDENTIFIER)){
            System.out.println("NEW CREATED HEREE");
            Point point = this.position;
            Gatherer gatherer1 =new Gatherer(new Point(point),
                    Direction.rotation90(this.direction,Direction.CLOCKWISE));
            Gatherer gatherer2 =new Gatherer(new Point(point),
                    Direction.rotation90(this.direction,Direction.ANTICLOCKWISE));
            System.out.println("CREATED HEERE  "+this.position);
            World.characters.add(gatherer1);
            World.characters.add(gatherer2);

            //gatherer1.render();
            //gatherer2.render();
            System.out.println("initial position {1} "+gatherer1.position.toString());
            System.out.println("initial position {2} "+gatherer2.position.toString());
            gatherer1.move(gatherer1.direction, World.TILE_SIZE);
            gatherer2.move(gatherer2.direction, World.TILE_SIZE);
            gatherer1.standingOn = World.charMap.get(World.tileNumCalculator(gatherer1.position));
            gatherer2.standingOn = World.charMap.get(World.tileNumCalculator(gatherer1.position));
            System.out.println("final position {1} "+gatherer1.position.toString());
            System.out.println("final position {2}"+gatherer2.position.toString());
            World.characters.remove(this);

        }

    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point position) {
        this.position = position;
    }

    public int getMoveDir() {
        return direction;
    }

    public void setMoveDir(int moveDir) {
        this.direction = moveDir;
    }


    /* Method to move the gatherer at a particular direction
     *  for specified no of tiles
     * */
    public void move(int direction, int tile) {
        System.out.println("direction "+direction);
        if(direction==2){
            System.out.println("IT IS GOING DOWN DOWN");
        }
        switch (direction) {
            case Direction.LEFT:
                this.position.setX((this.position.getX()) - (tile));
                break;
            case Direction.RIGHT:
                this.position.setX((this.position.getX()) + (tile));
                break;
            case Direction.UP:
                this.position.setY(this.position.getY() - (tile));
                break;
            case Direction.DOWN:
                this.position.setY(this.position.getY() + (tile));
                break;
            default:
                System.out.println("Wrong direction entered!");
                break;
        }
    }
}

