package OOSD.ass2;

import java.util.ArrayList;

public abstract class Player extends Actor{
    public int direction;
    public boolean carrying;
    public boolean active;
    public ArrayList<Actor> standingOn;

    public abstract void interact(Actor object);

    public void move(int direction, int tile) {
        switch (direction) {
            case Direction.LEFT:
                this.position.setX((this.position.getX()) - (tile));
                break;
            case Direction.RIGHT:
                this.position.setX((this.position.getX()) + (tile));
                break;
            case Direction.UP:
                this.position.setY(this.position.getY() - (tile));
                break;
            case Direction.DOWN:
                this.position.setY(this.position.getY() + (tile));
                break;
            default:
                System.out.println("Wrong direction entered!");
                break;
        }
    }
}
