package OOSD.ass2;

import bagel.Image;

public abstract class Actor {
    public Image image;
    public Point position;
    public String type;

    public void render(){
        this.image.drawFromTopLeft(this.position.getX(),this.position.getY());
    }

    public abstract void update(Tick tick);
}
