package OOSD.ass2;

import bagel.Image;

public class MitosisPool extends Actor {
    public static final String IDENTIFIER= "Pool";

    public  MitosisPool(Point position){
        this.type = "Pool";
        this.position = new Point(position);
        this.image = new Image("res/images/pool.png");
    }

    @Override
    public void update(Tick tick) {
        render();
    }
}
